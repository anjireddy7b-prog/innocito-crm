import { Request } from 'express';
import { and, asc, desc, eq, ilike, inArray, or, count, SQL } from 'drizzle-orm';
import { db } from '@/config/db';
import { leads, companies, contacts, campaigns, meetings, tasks, documents, comments } from '@/db/schema';
import { ApiError } from '@/utils/ApiError';
import { recordAudit } from '@/utils/auditLogger';
import { recordActivity } from '@/utils/activityLogger';
import { notifyUser } from '@/utils/notifier';
import { paginationMeta, toSkipTake } from '@/utils/pagination';
import { formatLeadNumber, parseLeadNumber } from '@/utils/leadNumber';
import { cache } from '@/config/redis';
import { PERMISSIONS } from '@/utils/permissions';
import { normalizeWebsite } from '@/utils/leadFormOptions';
import { orgId } from '@/utils/tenant';
import { validateAndNormalizeCustomFields } from '@/modules/customFields/customFields.service';

/**
 * Combines a calendar date with an "HH:MM" time-of-day into one Date, the same "naive wall-clock,
 * no real timezone math" convention the rest of the app already uses for meeting/lead dates (see
 * utils/spreadsheetImport.ts's parseFlexibleDate). The selected timezone is stored alongside on the
 * meeting record for display/reference, not used to convert this into a true UTC instant.
 */
function combineDateAndTime(date: Date, time?: string | null): Date {
  const [hh, mm] = (time ?? '00:00').split(':').map(Number);
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), hh || 0, mm || 0));
}

const leadWith = {
  company: { columns: { id: true, name: true, domain: true, industry: true, country: true, state: true, website: true, annualRevenue: true } },
  contact: { columns: { id: true, firstName: true, lastName: true, email: true, phone: true, designation: true } },
  campaign: { columns: { id: true, name: true, code: true } },
  assignedTo: { columns: { id: true, firstName: true, lastName: true, email: true } },
  currentOwner: { columns: { id: true, firstName: true, lastName: true, email: true } },
  sdr: { columns: { id: true, firstName: true, lastName: true, email: true } },
  createdBySdr: { columns: { id: true, firstName: true, lastName: true, email: true } },
  createdBy: { columns: { id: true, firstName: true, lastName: true } },
} as const;

function serializeLead(lead: any) {
  return { ...lead, displayId: formatLeadNumber(lead.leadNumber) };
}

async function withCounts(lead: any) {
  const [[{ value: m }], [{ value: t }], [{ value: d }], [{ value: c }]] = await Promise.all([
    db.select({ value: count() }).from(meetings).where(eq(meetings.leadId, lead.id)),
    db.select({ value: count() }).from(tasks).where(eq(tasks.leadId, lead.id)),
    db.select({ value: count() }).from(documents).where(eq(documents.leadId, lead.id)),
    db.select({ value: count() }).from(comments).where(eq(comments.leadId, lead.id)),
  ]);
  return { ...lead, _count: { meetings: Number(m), tasks: Number(t), documents: Number(d), leadComments: Number(c) } };
}

function canEditLead(req: Request, lead: { assignedToId: string | null; currentOwnerId: string | null; createdById: string | null }) {
  const perms = req.user!.permissions;
  if (perms.includes(PERMISSIONS.LEADS_EDIT_ANY)) return true;
  if (!perms.includes(PERMISSIONS.LEADS_EDIT_OWN)) return false;
  const uid = req.user!.sub;
  return lead.assignedToId === uid || lead.currentOwnerId === uid || lead.createdById === uid;
}

export async function listLeads(org: string, query: {
  page: number;
  pageSize: number;
  search?: string;
  status?: string;
  source?: string;
  priority?: string;
  campaignId?: string;
  assignedToId?: string;
  currentOwnerId?: string;
  sdrId?: string;
  createdBySdrId?: string;
  companyId?: string;
  country?: string;
  industry?: string;
  dateFrom?: Date;
  dateTo?: Date;
  sortBy?: string;
  sortDir: 'asc' | 'desc';
}) {
  const conditions: SQL[] = [eq(leads.organizationId, org), eq(leads.isActive, true)];

  if (query.search) {
    const asNumber = parseLeadNumber(query.search);
    const term = `%${query.search}%`;
    conditions.push(
      or(
        ...(asNumber !== null ? [eq(leads.leadNumber, asNumber)] : []),
        ilike(companies.name, term),
        ilike(companies.domain, term),
        ilike(companies.industry, term),
        ilike(companies.website, term),
        ilike(contacts.firstName, term),
        ilike(contacts.lastName, term),
        ilike(contacts.email, term),
        ilike(contacts.phone, term),
        ilike(campaigns.name, term),
        ilike(leads.emailResponse, term)
      )!
    );
  }
  if (query.status) conditions.push(inArray(leads.status, query.status.split(',') as any));
  if (query.source) conditions.push(inArray(leads.source, query.source.split(',') as any));
  if (query.priority) conditions.push(inArray(leads.priority, query.priority.split(',') as any));
  if (query.campaignId) conditions.push(eq(leads.campaignId, query.campaignId));
  if (query.assignedToId) conditions.push(eq(leads.assignedToId, query.assignedToId));
  if (query.currentOwnerId) conditions.push(eq(leads.currentOwnerId, query.currentOwnerId));
  if (query.sdrId) conditions.push(eq(leads.sdrId, query.sdrId));
  if (query.createdBySdrId) conditions.push(eq(leads.createdBySdrId, query.createdBySdrId));
  if (query.companyId) conditions.push(eq(leads.companyId, query.companyId));
  if (query.country) conditions.push(eq(companies.country, query.country));
  if (query.industry) conditions.push(eq(companies.industry, query.industry));

  const where = and(...conditions);

  const sortable: Record<string, any> = {
    createdAt: leads.createdAt,
    updatedAt: leads.updatedAt,
    status: leads.status,
    priority: leads.priority,
    dealValue: leads.dealValue,
    expectedCloseDate: leads.expectedCloseDate,
    leadNumber: leads.leadNumber,
  };
  const orderCol = sortable[query.sortBy ?? ''] ?? leads.createdAt;
  const orderBy = query.sortDir === 'asc' ? asc(orderCol) : desc(orderCol);

  const baseQuery = db
    .select({ id: leads.id })
    .from(leads)
    .leftJoin(companies, eq(leads.companyId, companies.id))
    .leftJoin(contacts, eq(leads.contactId, contacts.id))
    .leftJoin(campaigns, eq(leads.campaignId, campaigns.id))
    .where(where)
    .orderBy(orderBy)
    .$dynamic();

  const [idRows, [{ value: total }]] = await Promise.all([
    baseQuery.limit(query.pageSize).offset(toSkipTake(query.page, query.pageSize).skip),
    db
      .select({ value: count() })
      .from(leads)
      .leftJoin(companies, eq(leads.companyId, companies.id))
      .leftJoin(contacts, eq(leads.contactId, contacts.id))
      .leftJoin(campaigns, eq(leads.campaignId, campaigns.id))
      .where(where),
  ]);

  const ids = idRows.map((r) => r.id);
  const rows = ids.length
    ? await db.query.leads.findMany({ where: inArray(leads.id, ids), with: leadWith })
    : [];
  const byId = new Map(rows.map((r) => [r.id, r]));
  const ordered = ids.map((id) => byId.get(id)).filter(Boolean);
  const withCountsRows = await Promise.all(ordered.map(withCounts));

  return { data: withCountsRows.map(serializeLead), meta: paginationMeta(Number(total), query.page, query.pageSize) };
}

export async function getLeadById(org: string, id: string) {
  const lead = await db.query.leads.findFirst({
    where: and(eq(leads.organizationId, org), eq(leads.id, id)),
    with: {
      ...leadWith,
      meetings: { orderBy: (m, { desc }) => desc(m.scheduledAt) },
      tasks: { orderBy: (t, { asc }) => asc(t.dueDate), with: { assignedTo: { columns: { id: true, firstName: true, lastName: true } } } },
      documents: { orderBy: (d, { desc }) => desc(d.createdAt), with: { uploadedBy: { columns: { id: true, firstName: true, lastName: true } } } },
      leadComments: { orderBy: (c, { desc }) => desc(c.createdAt), with: { user: { columns: { id: true, firstName: true, lastName: true, avatarUrl: true } } } },
      activities: { orderBy: (a, { desc }) => desc(a.createdAt), limit: 100, with: { user: { columns: { id: true, firstName: true, lastName: true } } } },
    },
  });
  if (!lead) throw ApiError.notFound('Lead not found');
  const withC = await withCounts(lead);
  return serializeLead(withC);
}

async function resolveCompanyAndContact(req: Request, input: any) {
  const org = orgId(req);
  let companyId: string | null = input.companyId ?? null;
  if (!companyId && input.companyName) {
    const existing = await db.query.companies.findFirst({
      where: and(eq(companies.organizationId, org), ilike(companies.name, input.companyName)),
    });
    if (existing) {
      // Existing company: never overwrite its Industry/Country/State/Website/Revenue from this
      // lead's inline `company` details — those belong to the company record and are shared
      // across every lead for it, so a second lead for a known company must not silently mutate it.
      companyId = existing.id;
    } else {
      const details = input.company ?? {};
      const [created] = await db
        .insert(companies)
        .values({
          organizationId: org,
          name: input.companyName,
          industry: details.industry ?? null,
          country: details.country ?? null,
          state: details.state ?? null,
          website: normalizeWebsite(details.website) ?? null,
          annualRevenue: details.annualRevenue?.toString(),
          createdById: req.user!.sub,
        })
        .returning();
      companyId = created.id;
    }
  }

  let contactId: string | null = input.contactId ?? null;
  if (!contactId && input.contact) {
    const [created] = await db
      .insert(contacts)
      .values({ ...input.contact, email: input.contact.email || null, companyId, organizationId: org, createdById: req.user!.sub })
      .returning();
    contactId = created.id;
  }

  return { companyId, contactId };
}

export async function createLead(req: Request, input: any) {
  const org = orgId(req);
  const { companyId, contactId } = await resolveCompanyAndContact(req, input);
  // Phase 4: validated/normalized against this org's LEAD field definitions — rejects unknown
  // keys, checks per-type shape, and enforces required fields (see customFields.service.ts).
  // Called even when input.customFields is undefined, so a required custom field can't be
  // silently skipped just because the caller never mentioned it.
  const customFields = await validateAndNormalizeCustomFields(org, 'LEAD', input.customFields);

  const [created] = await db
    .insert(leads)
    .values({
      organizationId: org,
      companyId,
      contactId,
      campaignId: input.campaignId ?? null,
      source: input.source,
      status: input.status,
      priority: input.priority,
      category: input.category,
      dealValue: input.dealValue?.toString(),
      currency: input.currency ?? 'USD',
      probability: input.probability,
      expectedCloseDate: input.expectedCloseDate,
      tags: input.tags ?? [],
      customFields,
      assignedToId: input.assignedToId,
      currentOwnerId: input.currentOwnerId,
      sdrId: input.sdrId,
      createdBySdrId: input.createdBySdrId,
      leadReceivedDate: input.leadReceivedDate ?? undefined, // defaults to now() at the DB layer when omitted
      meetingDetails: input.meetingDetails,
      emailResponse: input.emailResponse,
      mom: input.mom,
      nextSteps: input.nextSteps,
      createdById: req.user!.sub,
    })
    .returning();

  // Optional meeting captured directly on the Lead Creation form — mirrors the meeting-creation
  // behavior the CSV import already has (see leads.import.service.ts) so both entry paths agree.
  if (input.meetingScheduledDate) {
    const scheduledAt = combineDateAndTime(new Date(input.meetingScheduledDate), input.meetingScheduledTime);
    await db.insert(meetings).values({
      organizationId: org,
      leadId: created.id,
      title: 'Initial Meeting',
      type: 'DISCOVERY',
      status: 'SCHEDULED',
      scheduledAt,
      timeZone: input.meetingTimeZone || null,
      createdById: req.user!.sub,
    });
    await recordActivity({
      organizationId: org,
      type: 'MEETING_SCHEDULED',
      description: `Meeting scheduled for ${formatLeadNumber(created.leadNumber)}`,
      leadId: created.id,
      userId: req.user!.sub,
    });
  }

  const lead = await getLeadById(org, created.id);

  await recordActivity({
    organizationId: org,
    type: 'LEAD_CREATED',
    description: `Lead ${formatLeadNumber(created.leadNumber)} created`,
    leadId: created.id,
    userId: req.user!.sub,
  });
  if (created.assignedToId) {
    await notifyUser({
      userId: created.assignedToId,
      type: 'LEAD_ASSIGNED',
      title: 'New lead assigned',
      message: `You were assigned lead ${formatLeadNumber(created.leadNumber)}${lead.company ? ` for ${(lead as any).company.name}` : ''}.`,
      leadId: created.id,
    });
  }
  if (created.sdrId && created.sdrId !== created.assignedToId) {
    await notifyUser({
      userId: created.sdrId,
      type: 'LEAD_ASSIGNED',
      title: 'You were set as SDR on a new lead',
      message: `You were set as SDR for lead ${formatLeadNumber(created.leadNumber)}${lead.company ? ` for ${(lead as any).company.name}` : ''}.`,
      leadId: created.id,
    });
  }
  await recordAudit({ req, action: 'CREATE', entityType: 'Lead', entityId: created.id, newValues: created });
  await cache.del('dashboard:*');

  return lead;
}

export async function updateLead(req: Request, id: string, input: any) {
  const org = orgId(req);
  const before = await db.query.leads.findFirst({ where: and(eq(leads.organizationId, org), eq(leads.id, id)) });
  if (!before) throw ApiError.notFound('Lead not found');
  if (!canEditLead(req, before)) throw ApiError.forbidden('You do not have permission to edit this lead');

  const needsResolve = input.companyId || input.companyName || input.contactId || input.contact;
  const { companyId, contactId } = needsResolve
    ? await resolveCompanyAndContact(req, input)
    : { companyId: undefined, contactId: undefined };

  // Phase 4: full-replace, same as `tags` just below — only re-validated/stored when the caller
  // actually included a customFields key in the request, so a PATCH that doesn't mention custom
  // fields at all leaves the lead's existing bag untouched rather than wiping it to {}.
  const customFields =
    input.customFields !== undefined ? await validateAndNormalizeCustomFields(org, 'LEAD', input.customFields) : undefined;

  await db
    .update(leads)
    .set({
      ...(companyId !== undefined ? { companyId } : {}),
      ...(contactId !== undefined ? { contactId } : {}),
      ...(input.campaignId !== undefined ? { campaignId: input.campaignId } : {}),
      source: input.source,
      priority: input.priority,
      category: input.category,
      dealValue: input.dealValue !== undefined ? input.dealValue?.toString() : undefined,
      currency: input.currency,
      probability: input.probability,
      expectedCloseDate: input.expectedCloseDate,
      actualCloseDate: input.actualCloseDate,
      lossReason: input.lossReason,
      tags: input.tags,
      ...(customFields !== undefined ? { customFields } : {}),
      // Note: assignedToId/currentOwnerId are intentionally NOT settable here — they go through
      // assignLead() below, which fires its own notification/audit trail. sdrId has no equivalent
      // dedicated endpoint (yet), so it's safe to fold into the general update.
      ...(input.sdrId !== undefined ? { sdrId: input.sdrId } : {}),
      ...(input.createdBySdrId !== undefined ? { createdBySdrId: input.createdBySdrId } : {}),
      ...(input.leadReceivedDate !== undefined ? { leadReceivedDate: input.leadReceivedDate } : {}),
      meetingDetails: input.meetingDetails,
      emailResponse: input.emailResponse,
      mom: input.mom,
      nextSteps: input.nextSteps,
      updatedAt: new Date(),
    })
    .where(eq(leads.id, id));

  // Unlike lead-creation time (where inline `company` details only ever apply to a brand-new
  // company, to protect a shared record from being clobbered by a guess), the Edit Lead form shows
  // the company's *actual current* Industry/Country/State/Website/Revenue and lets the user amend
  // them directly — the same fields, same validation, as editing the company from the Companies
  // page. Only applies when this lead already has a linked company; a lead with no company can't
  // carry company-detail edits.
  const effectiveCompanyId = companyId !== undefined ? companyId : before.companyId;
  if (input.company && effectiveCompanyId) {
    const details = input.company;
    await db
      .update(companies)
      .set({
        ...(details.industry !== undefined ? { industry: details.industry } : {}),
        ...(details.country !== undefined ? { country: details.country } : {}),
        ...(details.state !== undefined ? { state: details.state } : {}),
        ...(details.website !== undefined ? { website: normalizeWebsite(details.website) } : {}),
        ...(details.annualRevenue !== undefined ? { annualRevenue: details.annualRevenue?.toString() ?? null } : {}),
        updatedAt: new Date(),
      })
      .where(eq(companies.id, effectiveCompanyId));
  }

  // Meeting Schedule fields on Edit Lead mirror the ones on New Lead: they act on the lead's
  // "Initial Meeting" (the one created from this same form, at creation time or on a prior edit).
  // Other meetings added via the Meetings tab are untouched — this keeps the Edit Lead form scoped
  // to the single meeting it owns, rather than guessing which of possibly several meetings to change.
  if (input.meetingScheduledDate) {
    const scheduledAt = combineDateAndTime(new Date(input.meetingScheduledDate), input.meetingScheduledTime);
    const existingMeeting = await db.query.meetings.findFirst({
      where: and(eq(meetings.leadId, id), eq(meetings.title, 'Initial Meeting')),
    });
    if (existingMeeting) {
      await db
        .update(meetings)
        .set({ scheduledAt, timeZone: input.meetingTimeZone || null, updatedAt: new Date() })
        .where(eq(meetings.id, existingMeeting.id));
      await recordActivity({
        organizationId: org,
        type: 'MEETING_UPDATED',
        description: `Meeting rescheduled for ${formatLeadNumber(before.leadNumber)}`,
        leadId: id,
        userId: req.user!.sub,
      });
    } else {
      await db.insert(meetings).values({
        organizationId: org,
        leadId: id,
        title: 'Initial Meeting',
        type: 'DISCOVERY',
        status: 'SCHEDULED',
        scheduledAt,
        timeZone: input.meetingTimeZone || null,
        createdById: req.user!.sub,
      });
      await recordActivity({
        organizationId: org,
        type: 'MEETING_SCHEDULED',
        description: `Meeting scheduled for ${formatLeadNumber(before.leadNumber)}`,
        leadId: id,
        userId: req.user!.sub,
      });
    }
  }

  const lead = await getLeadById(org, id);

  await recordActivity({
    organizationId: org,
    type: 'LEAD_UPDATED',
    description: `Lead ${formatLeadNumber(before.leadNumber)} details updated`,
    leadId: id,
    userId: req.user!.sub,
  });
  await recordAudit({ req, action: 'UPDATE', entityType: 'Lead', entityId: id, oldValues: before, newValues: lead });
  await cache.del('dashboard:*');

  return lead;
}

export async function assignLead(req: Request, id: string, input: { assignedToId?: string | null; currentOwnerId?: string | null; note?: string }) {
  const org = orgId(req);
  const before = await db.query.leads.findFirst({ where: and(eq(leads.organizationId, org), eq(leads.id, id)) });
  if (!before) throw ApiError.notFound('Lead not found');

  await db
    .update(leads)
    .set({
      ...(input.assignedToId !== undefined ? { assignedToId: input.assignedToId } : {}),
      ...(input.currentOwnerId !== undefined ? { currentOwnerId: input.currentOwnerId } : {}),
      updatedAt: new Date(),
    })
    .where(eq(leads.id, id));

  const lead = await getLeadById(org, id);

  const changedOwner = input.currentOwnerId !== undefined && input.currentOwnerId !== before.currentOwnerId;
  const changedAssignee = input.assignedToId !== undefined && input.assignedToId !== before.assignedToId;

  await recordActivity({
    organizationId: org,
    type: before.assignedToId || before.currentOwnerId ? 'LEAD_REASSIGNED' : 'LEAD_ASSIGNED',
    description: `Lead ${formatLeadNumber(before.leadNumber)} reassigned${input.note ? `: ${input.note}` : ''}`,
    leadId: id,
    userId: req.user!.sub,
    metadata: { assignedToId: input.assignedToId, currentOwnerId: input.currentOwnerId },
  });

  if (changedAssignee && input.assignedToId) {
    await notifyUser({
      userId: input.assignedToId,
      type: 'LEAD_ASSIGNED',
      title: 'Lead assigned to you',
      message: `Lead ${formatLeadNumber(before.leadNumber)} was assigned to you.`,
      leadId: id,
    });
  }
  if (changedOwner && input.currentOwnerId) {
    await notifyUser({
      userId: input.currentOwnerId,
      type: 'LEAD_ASSIGNED',
      title: 'Lead ownership transferred to you',
      message: `Lead ${formatLeadNumber(before.leadNumber)} ownership was transferred to you.`,
      leadId: id,
    });
  }

  await recordAudit({
    req,
    action: 'ASSIGNMENT_CHANGED',
    entityType: 'Lead',
    entityId: id,
    oldValues: { assignedToId: before.assignedToId, currentOwnerId: before.currentOwnerId },
    newValues: { assignedToId: input.assignedToId, currentOwnerId: input.currentOwnerId },
  });
  await cache.del('dashboard:*');

  return lead;
}

export async function bulkAssignLeads(req: Request, input: { leadIds: string[]; assignedToId?: string | null; currentOwnerId?: string | null }) {
  const org = orgId(req);
  // Scoped by organization so a bulk-assign call can never touch another tenant's leads even if
  // a stray id from elsewhere ended up in leadIds.
  const owned = await db
    .select({ id: leads.id })
    .from(leads)
    .where(and(eq(leads.organizationId, org), inArray(leads.id, input.leadIds)));
  const ownedIds = owned.map((r) => r.id);

  await db
    .update(leads)
    .set({
      ...(input.assignedToId !== undefined ? { assignedToId: input.assignedToId } : {}),
      ...(input.currentOwnerId !== undefined ? { currentOwnerId: input.currentOwnerId } : {}),
      updatedAt: new Date(),
    })
    .where(inArray(leads.id, ownedIds));

  await Promise.all(
    ownedIds.map((leadId) =>
      recordActivity({ organizationId: org, type: 'LEAD_REASSIGNED', description: 'Bulk assignment update', leadId, userId: req.user!.sub })
    )
  );
  await recordAudit({ req, action: 'ASSIGNMENT_CHANGED', entityType: 'Lead', newValues: { ...input, leadIds: ownedIds } });
  await cache.del('dashboard:*');
  return { updated: ownedIds.length };
}

// Previously the lead pipeline enforced a strict stage order (e.g. you could
// not jump from DEMO_DONE straight to WON without passing through
// PROPOSAL_SENT / NEGOTIATION first). Per product decision, reps need to be
// able to set a lead to any status at any time — a deal can close faster
// than the paperwork stages suggest, or a rep may need to correct a
// mis-set status — so that restriction has been removed. The status value
// itself is still validated against the fixed enum of real statuses by the
// route's zod schema (`changeStatusSchema`), so this only lifts the
// "which stage can follow which stage" ordering rule, not the set of valid
// statuses.
export async function changeLeadStatus(req: Request, id: string, input: { status: string; lossReason?: string | null; note?: string }) {
  const org = orgId(req);
  const before = await db.query.leads.findFirst({ where: and(eq(leads.organizationId, org), eq(leads.id, id)) });
  if (!before) throw ApiError.notFound('Lead not found');
  if (!canEditLead(req, before)) throw ApiError.forbidden('You do not have permission to edit this lead');

  const isTerminal = ['WON', 'LOST', 'DISQUALIFIED'].includes(input.status);
  await db
    .update(leads)
    .set({
      status: input.status as any,
      lossReason: input.status === 'LOST' ? input.lossReason : undefined,
      actualCloseDate: isTerminal ? new Date() : undefined,
      updatedAt: new Date(),
    })
    .where(eq(leads.id, id));

  const lead = await getLeadById(org, id);

  await recordActivity({
    organizationId: org,
    type: 'STATUS_CHANGED',
    description: `Status changed from ${before.status} to ${input.status}${input.note ? `: ${input.note}` : ''}`,
    leadId: id,
    userId: req.user!.sub,
    metadata: { from: before.status, to: input.status },
  });

  const notifyTarget = before.currentOwnerId ?? before.assignedToId;
  if (notifyTarget && notifyTarget !== req.user!.sub) {
    await notifyUser({
      userId: notifyTarget,
      type: 'STATUS_CHANGED',
      title: 'Lead status updated',
      message: `Lead ${formatLeadNumber(before.leadNumber)} moved to ${input.status.replace(/_/g, ' ')}.`,
      leadId: id,
    });
  }

  await recordAudit({
    req,
    action: 'STATUS_CHANGED',
    entityType: 'Lead',
    entityId: id,
    oldValues: { status: before.status },
    newValues: { status: input.status },
  });
  await cache.del('dashboard:*');

  return lead;
}

export async function deleteLead(req: Request, id: string) {
  const org = orgId(req);
  const before = await db.query.leads.findFirst({ where: and(eq(leads.organizationId, org), eq(leads.id, id)) });
  if (!before) throw ApiError.notFound('Lead not found');
  await db.update(leads).set({ isActive: false, updatedAt: new Date() }).where(eq(leads.id, id));
  await recordAudit({ req, action: 'DELETE', entityType: 'Lead', entityId: id, oldValues: before });
  await cache.del('dashboard:*');
}
