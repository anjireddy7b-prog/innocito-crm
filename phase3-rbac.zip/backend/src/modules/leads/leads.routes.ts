import { Router } from 'express';
import { authenticate, requirePermission } from '@/middleware/auth';
import { validate } from '@/middleware/validate';
import { PERMISSIONS } from '@/utils/permissions';
import { leadImportUpload } from './import.middleware';
import {
  createLeadSchema,
  updateLeadSchema,
  assignLeadSchema,
  changeStatusSchema,
  listLeadsQuerySchema,
  bulkAssignSchema,
} from './leads.validation';
import * as controller from './leads.controller';

export const leadsRouter = Router();

leadsRouter.use(authenticate);
leadsRouter.use(requirePermission(PERMISSIONS.LEADS_VIEW));

leadsRouter.get('/', validate(listLeadsQuerySchema, 'query'), controller.list);
leadsRouter.post(
  '/import',
  requirePermission(PERMISSIONS.LEADS_CREATE),
  leadImportUpload.single('file'),
  controller.importFile
);
leadsRouter.get('/:id', controller.getById);
leadsRouter.post('/', requirePermission(PERMISSIONS.LEADS_CREATE), validate(createLeadSchema), controller.create);
leadsRouter.patch('/:id', validate(updateLeadSchema), controller.update);
leadsRouter.patch('/:id/assign', requirePermission(PERMISSIONS.LEADS_ASSIGN), validate(assignLeadSchema), controller.assign);
leadsRouter.post('/bulk-assign', requirePermission(PERMISSIONS.LEADS_ASSIGN), validate(bulkAssignSchema), controller.bulkAssign);
leadsRouter.patch('/:id/status', validate(changeStatusSchema), controller.changeStatus);
// Phase 3: was requireRole('ADMIN') — a hardcoded role-name check that would silently stop
// enforcing anything for a renamed or custom role. LEADS_DELETE is granted to ADMIN by default
// (see utils/permissions.ts's ROLE_PERMISSIONS) so this is a zero-behavior-change swap today.
leadsRouter.delete('/:id', requirePermission(PERMISSIONS.LEADS_DELETE), controller.remove);
